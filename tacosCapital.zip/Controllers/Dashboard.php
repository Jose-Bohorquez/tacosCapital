<?php
class Dashboard {
    public function index() {
        // Incluir la vista correspondiente para Dashboard
        include VIEWS_DIR . 'dashboard.php';
    }
    
    // Puedes agregar más métodos según necesites
}
