</main>
<script src="Assets/Dep/Landing/bootstrap/assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/e804fa0065.js" crossorigin="anonymous"></script>

    </body>
</html>