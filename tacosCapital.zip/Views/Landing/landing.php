<?php require_once('Views/Landing/Layouts/header1.php') ?>
<?php require_once('Views/Landing/Layouts/botonTema2.php') ?>
<?php require_once('Views/Landing/Layouts/navbar3.php') ?>
<?php require_once('Views/Landing/Pages/inicio.php') ?>
<?php require_once('Views/Landing/Layouts/footer5.php') ?>